package edu.century.finalproject.constants;

public interface GUIButtonCaptions {

	/**
	 * Button Captions
	 */
	public static final String BUTTON_CAPTION_SEARCH = "Find Movies";
	public static final String BUTTON_CAPTION_LOGIN  = "Sign In";
}
