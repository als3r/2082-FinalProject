package edu.century.finalproject;

public class MovieTime {

	String time;
	
	public MovieTime(String time) {
		this.time = time;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}
}
