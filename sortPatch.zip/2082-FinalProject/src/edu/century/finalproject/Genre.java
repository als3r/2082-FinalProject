package edu.century.finalproject;

public class Genre implements Comparable<Genre>{
	
	String name;
	
	public Genre(String genre) {
		name = genre;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public int compareTo(Genre o) {
		return this.getName().compareTo(o.getName());
	}

}
